import os
import random

import numpy as np
from tensorflow_core._api.v2.compat import v1 as tf

import logger_mod as loggermod
import models.esim
import parameters
from snli_util.evaluate import evaluate_classifier


# from train_snli import FIXED_PARAMETERS, modname, logger


def get_logger(parameters, modname):
    logpath = os.path.join(parameters['log_path'], modname) + '.log'
    logger = loggermod.Logger(logpath)
    return logger


class ModelTrainer:
    def __init__(self, loaded_embeddings, logger, modname, num_labels=3):
        self.logger = logger
        self.modname = modname
        self.num_labels = num_labels
        self.parameters = parameters.parameters
        self.learning_rate = self.parameters["learning_rate"]
        self.display_epoch_freq = 1
        self.display_step_freq = 50
        self.embedding_dim = self.parameters["word_embedding_dim"]
        self.dim = self.parameters["hidden_embedding_dim"]
        self.batch_size = self.parameters["batch_size"]
        self.keep_rate = self.parameters["keep_rate"]
        self.sequence_length = self.parameters["seq_length"]

        self.model = models.esim.EsimModel(seq_length=self.sequence_length, emb_dim=self.embedding_dim,
                                           hidden_dim=self.dim,
                                           embeddings=loaded_embeddings,
                                           emb_train=False,
                                           num_labels=num_labels)

        # Perform gradient descent with Adam
        self.optimizer = tf.train.AdamOptimizer(self.learning_rate, beta1=0.9, beta2=0.999).minimize(
            self.model.total_cost)

        # Boolean stating that training has not been completed,
        self.completed = False

        # tf things: initialize variables and create placeholder for session
        self.logger.Log("Initializing variables")
        self.init = tf.global_variables_initializer()
        self.sess = None
        self.saver = tf.train.Saver()

    def get_minibatch(self, dataset, start_index, end_index):
        indices = range(start_index, end_index)
        premise_vectors = np.vstack([dataset[i]['sentence0_index_sequence'] for i in indices])
        hypothesis_vectors = np.vstack([dataset[i]['sentence1_index_sequence'] for i in indices])
        genres = ['none' for i in indices]
        labels = [dataset[i]['label'] for i in indices]
        return premise_vectors, hypothesis_vectors, labels, genres

    def restore(self, best=True):
        if best:
            path = os.path.join(self.parameters["ckpt_path"], self.modname) + ".ckpt_best"
        else:
            path = os.path.join(self.parameters["ckpt_path"], self.modname) + ".ckpt"
        self.sess = tf.Session()
        self.sess.run(self.init)
        self.saver.restore(self.sess, path)
        self.logger.Log("Model restored from file: %s" % path)

    def classify(self, examples):
        # This classifies a list of examples
        total_batch = int(len(examples) / self.batch_size)
        logits = np.empty(self.num_labels)
        genres = []
        for i in range(total_batch):
            minibatch_premise_vectors, minibatch_hypothesis_vectors, minibatch_labels, minibatch_genres = self.get_minibatch(
                examples, self.batch_size * i, self.batch_size * (i + 1))
            feed_dict = {self.model.premise_x: minibatch_premise_vectors,
                         self.model.hypothesis_x: minibatch_hypothesis_vectors,
                         self.model.y: minibatch_labels,
                         self.model.keep_rate_ph: 1.0}
            genres += minibatch_genres
            logit, cost = self.sess.run([self.model.logits, self.model.total_cost], feed_dict)
            logits = np.vstack([logits, logit])

        return genres, np.argmax(logits[1:], axis=1), cost

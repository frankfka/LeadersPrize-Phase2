import os

import bs4
import tensorflow.compat.v1 as tf
import numpy as np
import models.esim

tf.disable_v2_behavior()


def read_all(path: str):
    file_names = os.listdir(path)
    for file_name in file_names:
        with open(f'{path}/{file_name}', errors='ignore') as f:
            text = f.read()
            yield file_name, text


def strip_newlines(text: str) -> str:
    text = text.replace('\n', '')
    return text


def parse_html(html: str) -> str:
    soup = bs4.BeautifulSoup(html, 'html.parser')

    bad_parents = [
        '[document]',
        'noscript',
        'header',
        'html',
        'meta',
        'head',
        'input',
        'script',
        'style'
    ]

    texts = soup.find_all(text=True)
    texts = [text for text in texts if text.count(' ') > 0]
    texts = [text for text in texts if text.count(';') == 0]
    texts = [text for text in texts if len(text) > 5]
    texts = [text for text in texts
             if text.parent.name not in bad_parents]

    # remove extra whitespace
    texts = [' '.join(text.split()) for text in texts]

    combined_text = ' '.join(texts)
    return combined_text


def load_articles(path='datainput'):
    article_names = []
    articles = []
    for data_names, html in read_all(f'../data/{path}'):
        article = parse_html(html)
        articles.append(article)
        article_names.append(data_names)
    return article_names, articles


class modelClassifier:
    def __init__(self, loaded_embeddings, processing, logger, modname,
                 num_labels=3):
        tf.reset_default_graph()
        self.processing = processing
        self.logger = logger
        self.num_labels = num_labels

        self.modname = modname

        ## Define hyperparameters
        self.learning_rate = self.processing.FIXED_PARAMETERS["learning_rate"]
        self.display_epoch_freq = 1
        self.display_step_freq = 50
        self.emb_train = False
        self.embedding_dim = self.processing.FIXED_PARAMETERS["word_embedding_dim"]
        self.dim = self.processing.FIXED_PARAMETERS["hidden_embedding_dim"]
        self.batch_size = self.processing.FIXED_PARAMETERS["batch_size"]
        self.keep_rate = self.processing.FIXED_PARAMETERS["keep_rate"]
        self.sequence_length = self.processing.FIXED_PARAMETERS["seq_length"]

        self.model = models.esim.EsimModel(seq_length=self.sequence_length,
                                           emb_dim=self.embedding_dim,
                                           hidden_dim=self.dim,
                                           embeddings=loaded_embeddings,
                                           emb_train=self.emb_train,
                                           num_labels=self.num_labels
                                           )

        # Perform gradient descent with Adam
        self.optimizer = tf.train.AdamOptimizer(self.learning_rate, beta1=0.9, beta2=0.999).minimize(
            self.model.total_cost)

        # tf things: initialize variables and create placeholder for session
        self.logger.Log("Initializing variables")
        self.init = tf.global_variables_initializer()
        self.sess = None
        self.saver = tf.train.Saver()

    def get_minibatch(self, dataset, start_index, end_index):
        batch = dataset[start_index: end_index]
        premise_vectors = np.vstack(batch['sentence0_index_sequence'])
        hypothesis_vectors = np.vstack(batch['sentence1_index_sequence'])
        return premise_vectors, hypothesis_vectors

    def restore(self):
        best_path = os.path.join(self.processing.FIXED_PARAMETERS["ckpt_path"], self.modname) + ".ckpt_best"
        self.sess = tf.Session()
        self.sess.run(self.init)
        self.saver.restore(self.sess, best_path)
        self.logger.Log("Model restored from file: %s" % best_path)

    def classify(self, examples):
        self.restore()
        return self.continue_classify(examples)

    def continue_classify(self, examples):
        logits = np.empty(self.num_labels)
        minibatch_premise_vectors, minibatch_hypothesis_vectors = self.get_minibatch(examples, 0, len(examples))
        feed_dict = {self.model.premise_x: minibatch_premise_vectors,
                     self.model.hypothesis_x: minibatch_hypothesis_vectors,
                     self.model.keep_rate_ph: 1.0}
        logit = self.sess.run(self.model.logits, feed_dict)
        logits = np.vstack([logits, logit])

        return np.argmax(logits[1:], axis=1)


hypotheses = [
    'I think Super Bowl does not symbolize progress at all.',
    'Hand washing causes spread of viral infections ',
    'When I was mayor of New York City, I encouraged adoptions. Adoptions went up 65 to 70 percent; '
    'abortions went down 16 percent.',
    'Hilary said that democrats are united for the change',
    'Black people are more likely to receive death sentences in the US',
    'Super Bowl does not symbolize progress at all.', ]

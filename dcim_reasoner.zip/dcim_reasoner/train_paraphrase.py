"""
Training script to train a model on the MSR Paraphrase Corpus.
"""
import os
import pickle

import tensorflow.compat.v1 as tf

import importlib

import data_processing
import parameters
import paraphrase_util.data_processing as paraphrase_processing
import paraphrase_util.evaluate as evaluate
import numpy as np

import train_shared
import vocab

tf.disable_v2_behavior()


class ParaphraseModelTrainer(train_shared.ModelTrainer):
    def get_minibatch(self, dataset, start_index, end_index):
        batch = dataset[start_index:end_index]
        premise_vectors = batch['sentence0_index_sequence'].to_list()
        hypothesis_vectors = batch['sentence1_index_sequence'].to_list()
        genres = ['none'] * len(batch)
        labels = batch['is_paraphrase'].to_list()
        return premise_vectors, hypothesis_vectors, labels, genres

    def train(self, train_data, dev_data):
        self.sess = tf.Session()
        self.sess.run(self.init)

        self.step = 1
        self.epoch = 0
        self.best_dev = 0.
        self.best_train_acc = 0.
        self.last_train_acc = [.001, .001, .001, .001, .001]
        self.best_step = 0

        # Restore most recent checkpoint if it exists. 
        # Also restore values for best dev-set accuracy and best training-set accuracy.
        ckpt_file = os.path.join(paraphrase_processing.FIXED_PARAMETERS["ckpt_path"], modname) + ".ckpt"
        if os.path.isfile(ckpt_file + ".meta"):
            if os.path.isfile(ckpt_file + "_best.meta"):
                self.saver.restore(self.sess, (ckpt_file + "_best"))
                best_dev_mat, dev_cost_mat = evaluate.evaluate_classifier(self.classify, dev_data,
                                                                          self.batch_size)
                self.best_dev, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
                self.best_train_acc, strain_cost = evaluate.evaluate_classifier(self.classify,
                                                                                train_data[
                                                                                0:5000],
                                                                                self.batch_size)
                logger.Log(
                    f"""Restored best matched-dev acc: {best_dev_mat}
Restored best acc: {self.best_dev}
Restored best SNLI train acc: {self.best_train_acc}""")

            self.saver.restore(self.sess, ckpt_file)
            logger.Log("Model restored from file: %s" % ckpt_file)

        ### Training cycle
        logger.Log("Training...")

        while True:
            # random.shuffle(train_data) # Already should be shuffled from when they were read.
            avg_cost = 0.
            total_batch = int(len(train_data) / self.batch_size)

            # Loop over all batches in epoch
            for i in range(total_batch):
                # Assemble a minibatch of the next B examples
                premise_vectors, hypothesis_vectors, labels, genres = self.get_minibatch(train_data,
                                                                                         self.batch_size * i,
                                                                                         self.batch_size * (i + 1))

                # Run the optimizer to take a gradient step, and also fetch the value of the
                # cost function for logging
                feed_dict = {self.model.premise_x: premise_vectors,
                             self.model.hypothesis_x: hypothesis_vectors,
                             self.model.y: labels,
                             self.model.keep_rate_ph: self.keep_rate}

                _, c = self.sess.run([self.optimizer, self.model.total_cost], feed_dict)

                # Since a single epoch can take a  ages for larger models (ESIM),
                #  we'll print accuracy every 50 steps
                if self.step % self.display_step_freq == 0:
                    dev_acc, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
                    strain_acc, strain_cost = evaluate.evaluate_classifier(self.classify, train_data[0:5000],
                                                                           self.batch_size)

                    logger.Log(f"Step: {self.step}\t Dev cost: {dev_cost}\t Dev acc: {dev_acc}")

                if self.step % 500 == 0:
                    self.saver.save(self.sess, ckpt_file)
                    best_test = 100 * (1 - self.best_dev / dev_acc)
                    if best_test > 0.04:
                        self.saver.save(self.sess, ckpt_file + "_best")
                        self.best_dev = dev_acc
                        self.best_train_acc = strain_acc
                        self.best_step = self.step
                        logger.Log("Checkpointing with new best SNLI-dev accuracy: %f" % (self.best_dev))

                self.step += 1

                # Compute average loss
                avg_cost += c / (total_batch * self.batch_size)

            # Display some statistics about the epoch
            if self.epoch % self.display_epoch_freq == 0:
                logger.Log("Epoch: %i\t Avg. Cost: %f" % (self.epoch + 1, avg_cost))

            self.epoch += 1
            self.last_train_acc[(self.epoch % 5) - 1] = strain_acc

            # Early stopping
            progress = 1000 * (sum(self.last_train_acc) / (len(self.last_train_acc) * min(self.last_train_acc)) - 1)

            if (progress < 0.1) or (self.step > self.best_step + 30000):
                logger.Log("Best dev accuracy: %s" % (self.best_dev))
                logger.Log("Best train accuracy: %s" % (self.best_train_acc))
                self.completed = True
                break


def load_paraphrase_data():
    corpus = 'MSRParaphraseCorpus'
    path = f'{parameters.data_path}/{corpus}/msr_paraphrase_all.tsv'
    train, dev, test = paraphrase_processing.split_paraphrase_data(
        paraphrase_processing.load_paraphrase_data(path),
        train_amount=0.6, dev_amount=0.2)
    return train, dev, test


def train_paraphrase_model(classifier, logger, train_data, dev_data, test_data):
    classifier.train(train_data, dev_data)
    logger.Log(
        "Acc: %s" % (evaluate.evaluate_classifier(classifier.classify, test_data, FIXED_PARAMETERS["batch_size"]))[0])


def test_paraphrase_model(classifier, logger, test_data):
    results = evaluate.evaluate_final(classifier.restore, classifier.classify, [test_data],
                                      FIXED_PARAMETERS["batch_size"])
    logger.Log("Acc: %s" % (results[0][0]))


if __name__ == '__main__':
    modname = 'ensemble_paraphrase'
    test = False

    FIXED_PARAMETERS = parameters.parameters
    logger = train_shared.get_logger(FIXED_PARAMETERS, modname)
    word_indices = vocab.load_dictionary()
    logger.Log("FIXED_PARAMETERS\n %s" % FIXED_PARAMETERS)

    logger.Log("Loading embeddings")
    loaded_embeddings = data_processing.loadEmbedding_rand(FIXED_PARAMETERS["embedding_data_path"], word_indices)

    train_data, dev_data, test_data = load_paraphrase_data()
    paraphrase_processing.sentences_to_padded_index_sequences(word_indices, [train_data, dev_data, test_data])

    classifier = ParaphraseModelTrainer(loaded_embeddings, logger, modname)
    if test:
        test_paraphrase_model(classifier, logger, test_data)
    else:
        train_paraphrase_model(classifier, logger, train_data, dev_data, test_data)

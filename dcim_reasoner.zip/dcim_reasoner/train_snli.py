"""
Training script to train a model on only SNLI data. MultiNLI data is loaded into the embeddings enabling us to test the model on MultiNLI data.
"""
import os

import tensorflow.compat.v1 as tf

import data_processing
import vocab

import snli_util.data_processing as nli_processing
import snli_util.evaluate
import train_shared
import parameters
import random

tf.disable_v2_behavior()


class SnliModelTrainer(train_shared.ModelTrainer):

    def train(self, train_mnli, train_snli, dev_mat, dev_mismat, dev_snli):
        self.sess = tf.Session()
        self.sess.run(self.init)

        self.step = 1
        self.epoch = 0
        self.best_dev_snli = 0.
        self.best_strain_acc = 0.
        self.last_train_acc = [.001, .001, .001, .001, .001]
        self.best_step = 0

        # Restore most recent checkpoint if it exists.
        # Also restore values for best dev-set accuracy and best training-set accuracy.
        ckpt_file = os.path.join(FIXED_PARAMETERS["ckpt_path"], self.modname) + ".ckpt"
        if os.path.isfile(ckpt_file + ".meta"):
            if os.path.isfile(ckpt_file + "_best.meta"):
                self.saver.restore(self.sess, (ckpt_file + "_best"))
                best_dev_mat, dev_cost_mat = snli_util.evaluate.evaluate_classifier(self.classify, dev_mat,
                                                                                    self.batch_size)
                best_dev_mismat, dev_cost_mismat = snli_util.evaluate.evaluate_classifier(self.classify, dev_mismat,
                                                                                          self.batch_size)
                self.best_dev_snli, dev_cost_snli = snli_util.evaluate.evaluate_classifier(self.classify, dev_snli,
                                                                                           self.batch_size)
                self.best_strain_acc, strain_cost = snli_util.evaluate.evaluate_classifier(self.classify,
                                                                                          train_snli[0:5000],
                                                                                           self.batch_size)
                self.logger.Log(
                    "Restored best matched-dev acc: %f\n Restored best mismatched-dev acc: %f\n Restored best SNLI-dev acc: %f\n Restored best SNLI train acc: %f" % (
                        best_dev_mat, best_dev_mismat, self.best_dev_snli, self.best_strain_acc))

            self.saver.restore(self.sess, ckpt_file)
            self.logger.Log("Model restored from file: %s" % ckpt_file)

        ### Training cycle
        self.logger.Log("Training...")

        while True:
            random.shuffle(train_snli)
            avg_cost = 0.
            total_batch = int(len(train_snli) / self.batch_size)

            # Loop over all batches in epoch
            for i in range(total_batch):
                # Assemble a minibatch of the next B examples
                minibatch_premise_vectors, minibatch_hypothesis_vectors, minibatch_labels, minibatch_genres = self.get_minibatch(
                    train_snli, self.batch_size * i, self.batch_size * (i + 1))

                # Run the optimizer to take a gradient step, and also fetch the value of the
                # cost function for logging
                feed_dict = {self.model.premise_x: minibatch_premise_vectors,
                             self.model.hypothesis_x: minibatch_hypothesis_vectors,
                             self.model.y: minibatch_labels,
                             self.model.keep_rate_ph: self.keep_rate}
                _, c = self.sess.run([self.optimizer, self.model.total_cost], feed_dict)

                # Since a single epoch can take a  ages for larger models (ESIM),
                #  we'll print accuracy every 50 steps
                if self.step % self.display_step_freq == 0:
                    dev_acc_mat, dev_cost_mat = snli_util.evaluate.evaluate_classifier(self.classify, dev_mat,
                                                                                       self.batch_size)
                    dev_acc_mismat, dev_cost_mismat = snli_util.evaluate.evaluate_classifier(self.classify, dev_mismat,
                                                                                             self.batch_size)
                    dev_acc_snli, dev_cost_snli = snli_util.evaluate.evaluate_classifier(self.classify, dev_snli,
                                                                                         self.batch_size)
                    strain_acc, strain_cost = snli_util.evaluate.evaluate_classifier(self.classify, train_snli[0:5000],
                                                                                     self.batch_size)

                    self.logger.Log(
                        "Step: %i\t Dev-matched acc: %f\t Dev-mismatched acc: %f\t Dev-SNLI acc: %f\t SNLI train acc: %f" % (
                            self.step, dev_acc_mat, dev_acc_mismat, dev_acc_snli, strain_acc))
                    self.logger.Log(
                        "Step: %i\t Dev-matched cost: %f\t Dev-mismatched cost: %f\t Dev-SNLI cost: %f\t SNLI train cost: %f" % (
                            self.step, dev_cost_mat, dev_cost_mismat, dev_cost_snli, strain_cost))

                if self.step % 500 == 0:
                    self.saver.save(self.sess, ckpt_file)
                    best_test = 100 * (1 - self.best_dev_snli / dev_acc_snli)
                    if best_test > 0.04:
                        self.saver.save(self.sess, ckpt_file + "_best")
                        self.best_dev_snli = dev_acc_snli
                        self.best_strain_acc = strain_acc
                        self.best_step = self.step
                        self.logger.Log("Checkpointing with new best SNLI-dev accuracy: %f" % (self.best_dev_snli))

                self.step += 1

                # Compute average loss
                avg_cost += c / (total_batch * self.batch_size)

            # Display some statistics about the epoch
            if self.epoch % self.display_epoch_freq == 0:
                self.logger.Log("Epoch: %i\t Avg. Cost: %f" % (self.epoch + 1, avg_cost))

            self.epoch += 1
            self.last_train_acc[(self.epoch % 5) - 1] = strain_acc

            # Early stopping
            progress = 1000 * (sum(self.last_train_acc) / (5 * min(self.last_train_acc)) - 1)

            if (progress < 0.1) or (self.step > self.best_step + 30000):
                self.logger.Log("Best snli-dev accuracy: %s" % (self.best_dev_snli))
                self.logger.Log("MultiNLI Train accuracy: %s" % (self.best_strain_acc))
                self.completed = True
                break


def load_snli_data():
    snli_path_term = 'snli_1.0'
    snli_base_path = f'{nli_processing.params.data_path}/{snli_path_term}/{snli_path_term}'
    training_snli = nli_processing.load_nli_data(f'{snli_base_path}_train.jsonl', snli=True)
    dev_snli = nli_processing.load_nli_data(f'{snli_base_path}_dev.jsonl', snli=True)
    test_snli = nli_processing.load_nli_data(f'{snli_base_path}_test.jsonl', snli=True)

    mnli_path_term = 'multinli_1.0'
    mnli_base_path = f'{nli_processing.params.data_path}/{mnli_path_term}/{mnli_path_term}'

    training_mnli = nli_processing.load_nli_data(f'{mnli_base_path}_train.jsonl')
    dev_matched = nli_processing.load_nli_data(f'{mnli_base_path}_dev_matched.jsonl')
    dev_mismatched = nli_processing.load_nli_data(f'{mnli_base_path}_dev_mismatched.jsonl')
    test_matched = dev_matched
    test_mismatched = dev_mismatched

    return training_snli, dev_snli, test_snli, training_mnli, dev_matched, dev_mismatched, test_matched, test_mismatched


def train_snli_model(classifier, logger, training_mnli, training_snli, dev_matched, dev_mismatched, dev_snli,
                     test_matched, test_mismatched, test_snli):
    classifier.train(training_mnli, training_snli, dev_matched, dev_mismatched, dev_snli)
    logger.Log("Acc on matched multiNLI dev-set: %s" %
               (snli_util.evaluate.evaluate_classifier(classifier.classify, test_matched,
                                                       FIXED_PARAMETERS["batch_size"]))[0])
    logger.Log("Acc on mismatched multiNLI dev-set: %s" %
               (snli_util.evaluate.evaluate_classifier(classifier.classify, test_mismatched,
                                                       FIXED_PARAMETERS["batch_size"]))[0])
    logger.Log("Acc on SNLI test-set: %s" %
               (snli_util.evaluate.evaluate_classifier(classifier.classify, test_snli, FIXED_PARAMETERS["batch_size"]))[
                   0])


def test_snli_model(classifier, logger, test_matched, test_mismatched, test_snli):
    results = snli_util.evaluate.evaluate_final(classifier.restore, classifier.classify,
                                                [test_matched, test_mismatched, test_snli],
                                                FIXED_PARAMETERS["batch_size"])
    logger.Log("Acc on multiNLI matched dev-set: %s" % (results[0][0]))
    logger.Log("Acc on multiNLI mismatched dev-set: %s" % (results[0][1]))
    logger.Log("Acc on SNLI test set: %s" % (results[0][2]))


if __name__ == '__main__':
    modname = 'ensemble_snli'
    test = False

    FIXED_PARAMETERS = parameters.parameters
    logger = train_shared.get_logger(FIXED_PARAMETERS, modname)
    word_indices = vocab.load_dictionary()
    logger.Log("FIXED_PARAMETERS\n %s" % FIXED_PARAMETERS)

    logger.Log("Loading embeddings")
    loaded_embeddings = data_processing.loadEmbedding_rand(FIXED_PARAMETERS["embedding_data_path"], word_indices)

    training_snli, dev_snli, test_snli, training_mnli, dev_matched, dev_mismatched, test_matched, test_mismatched \
        = load_snli_data()

    data_processing.sentences_to_padded_index_sequences(word_indices,
                                                        [training_mnli, training_snli,
                                                    dev_matched, dev_mismatched, dev_snli,
                                                    test_snli, test_matched, test_mismatched])

    classifier = SnliModelTrainer(loaded_embeddings, logger, modname)
    if test:
        test_snli_model(classifier, logger, test_matched, test_mismatched, test_snli)
    else:
        train_snli_model(classifier, logger, training_mnli, training_snli, dev_matched, dev_mismatched, dev_snli,
                         test_matched, test_mismatched, test_snli)

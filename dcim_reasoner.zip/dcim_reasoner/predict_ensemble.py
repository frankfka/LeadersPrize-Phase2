import pandas as pd
import typing

import data_processing
import snli_util
import predict_rumoreval
import predict_shared

import snli_util.data_processing
import snli_util.evaluate

import paraphrase_util.data_processing
import paraphrase_util.evaluate

import rumoreval_util.data_processing
import rumoreval_util.evaluate

import logger_mod
import vocab
from test_predict_ensemble import get_sentences


class EnsembleClassifier:
    def __init__(self):
        self.data_root_path = '../data'
        self.word_indices = vocab.load_dictionary()
        self.embedding_path = f'{self.data_root_path}/glove.6B.50d.txt'
        self.loaded_embeddings = data_processing.loadEmbedding_rand(self.embedding_path, self.word_indices)

        self.snli_classifier = self.init_snli()
        self.paraphrase_classifier = self.init_paraphrase()
        self.rumor_classifier = self.init_rumor()

    def predict_statement_in_contexts(self, statement: str, contexts: typing.List[str]):
        predictions = []
        for context in contexts:
            prediction = self.predict_statement_in_context(statement, context)
            predictions.append(prediction)
        return predictions

    def predict_statement_in_context(self, statement: str, context: str):
        data = self.build_statement_context_df(statement, context)
        snli_row = self.predict_snli(data)
        paraphrase_row = self.predict_paraphrase(data)
        rumor_row = self.predict_rumor(data)
        return {'entailment': snli_row, 'paraphrase': paraphrase_row, 'rumor': rumor_row}

    def build_statement_context_df(self, statement: str, context: str) -> pd.DataFrame:
        data = {'sentence0': context, 'sentence1': statement}
        data_processing.sentences_to_padded_index_sequences(self.word_indices, [[data]])
        data = pd.DataFrame([data])
        return data

    def init_snli(self):
        snli_classifier = predict_shared.modelClassifier(
            loaded_embeddings=self.loaded_embeddings,
            processing=snli_util.data_processing,
            logger=logger_mod.Logger(),
            modname='ensemble_snli')
        snli_classifier.restore()
        return snli_classifier

    def init_paraphrase(self):
        paraphrase_classifier = predict_shared.modelClassifier(
            loaded_embeddings=self.loaded_embeddings,
            processing=paraphrase_util.data_processing,
            logger=logger_mod.Logger(),
            modname='ensemble_paraphrase')
        paraphrase_classifier.restore()
        return paraphrase_classifier

    def init_rumor(self):
        rumor_classifier = predict_rumoreval.RumorEvalClassifier(
            loaded_embeddings=self.loaded_embeddings,
            processing=rumoreval_util.data_processing,
            logger=logger_mod.Logger(),
            modname='ensemble_rumoreval')
        rumor_classifier.restore()
        return rumor_classifier

    def predict_snli(self, data: pd.DataFrame):  # hypothesis: str, premise: str):
        result = self.snli_classifier.continue_classify(data)[0]
        label = snli_util.evaluate.INVERSE_MAP[result]
        return label

    def predict_paraphrase(self, data: pd.DataFrame):  # hypothesis: str, premise: str):
        result = self.paraphrase_classifier.continue_classify(data)[0]
        label = paraphrase_util.evaluate.INVERSE_MAP[result]
        return label

    def predict_rumor(self, data: pd.DataFrame):  # hypothesis: str, premise: str):
        result = self.paraphrase_classifier.continue_classify(data)[0]
        label = rumoreval_util.evaluate.INVERSE_MAP[result]
        return label


if __name__ == '__main__':
    text = ["Pigs are excellent fliers.",
            "The ground is under the sky.",
            "This statement is false."]
    claim = "I'll win the race."

    classifier = EnsembleClassifier()
    # for line in text:
    #     row = classifier.predict_statement(statement_id='1', statement=line, context=claim)
    #     print(f'{line} - {claim} - {row}')

    hypotheses = predict_shared.hypotheses
    article_names, articles = predict_shared.load_articles()

    for hypothesis in hypotheses:
        all_predictions = []
        for article_name, article in zip(article_names, articles):
            sentences = get_sentences(article)
            predictions = classifier.predict_statement_in_contexts(statement=hypothesis, contexts=sentences)

            for i, prediction in enumerate(predictions):
                prediction['sentence_id'] = f'{article_name}_{i}'
            all_predictions.append(predictions)

        print('debug')



    # for hypothesis_i, hypothesis in enumerate(hypotheses):
    #     hypothesis_predictions, scores = predict_for_hypothesis(hypothesis, articles, article_names)
    #     save_hypothesis_predictions(hypothesis_predictions)
    #     for article, score in scores:
    #         row = [hypothesis, article, score]
    #         csv_rows.append(row)

    print('debug')

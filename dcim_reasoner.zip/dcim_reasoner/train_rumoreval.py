"""
Training script to train a model on the rumoreval Corpus.
"""
import os
import pickle

import tensorflow.compat.v1 as tf

import importlib

import data_processing
import parameters
import rumoreval_util.data_processing as rumor_processing
import rumoreval_util.evaluate as evaluate
import numpy as np

import train_shared
import vocab

tf.disable_v2_behavior()


def load_rumor_data():
    train_data, dev_data, test_data = rumor_processing.split_rumor_data(
        rumor_processing.load_rumor_data(),
        train_amount=0.6, dev_amount=0.2)
    return train_data, dev_data, test_data


class RumorModelTrainer(train_shared.ModelTrainer):
    def __init__(self, loaded_embeddings, logger, modname):
        super().__init__(loaded_embeddings, logger, modname, num_labels=4)

    def get_minibatch(self, dataset, start_index, end_index):
        batch = dataset[start_index:end_index]
        premise_vectors = batch['text_index_sequence'].to_list()
        hypothesis_vectors = batch['text_index_sequence'].to_list()
        genres = ['none'] * len(batch)
        labels = batch['label'].to_list()
        return premise_vectors, hypothesis_vectors, labels, genres

    def train(self, train_data, dev_data):
        self.sess = tf.Session()
        self.sess.run(self.init)

        self.step = 1
        self.epoch = 0
        self.best_dev = 0.
        self.best_train_acc = 0.
        self.last_train_acc = [.001, .001, .001, .001, .001]
        self.best_step = 0

        # Restore most recent checkpoint if it exists. 
        # Also restore values for best dev-set accuracy and best training-set accuracy.
        ckpt_file = os.path.join(rumor_processing.FIXED_PARAMETERS["ckpt_path"], modname) + ".ckpt"
        if os.path.isfile(ckpt_file + ".meta"):
            if os.path.isfile(ckpt_file + "_best.meta"):
                self.saver.restore(self.sess, (ckpt_file + "_best"))
                best_dev_mat, dev_cost_mat = evaluate.evaluate_classifier(self.classify, dev_data,
                                                                          self.batch_size)
                self.best_dev, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
                self.best_train_acc, strain_cost = evaluate.evaluate_classifier(self.classify,
                                                                                train_data[
                                                                                0:5000],
                                                                                self.batch_size)
                logger.Log(
                    f"""Restored best matched-dev acc: {best_dev_mat}
Restored best acc: {self.best_dev}
Restored best SNLI train acc: {self.best_train_acc}""")

            self.saver.restore(self.sess, ckpt_file)
            logger.Log("Model restored from file: %s" % ckpt_file)

        ### Training cycle
        logger.Log("Training...")

        while True:
            # random.shuffle(train_data) # Already should be shuffled from when they were read.
            avg_cost = 0.
            total_batch = int(len(train_data) / self.batch_size)

            # Loop over all batches in epoch
            for i in range(total_batch):
                # Assemble a minibatch of the next B examples
                premise_vectors, hypothesis_vectors, labels, genres = self.get_minibatch(train_data,
                                                                                         self.batch_size * i,
                                                                                         self.batch_size * (i + 1))

                # Run the optimizer to take a gradient step, and also fetch the value of the
                # cost function for logging
                feed_dict = {self.model.premise_x: premise_vectors,
                             self.model.hypothesis_x: hypothesis_vectors,
                             self.model.y: labels,
                             self.model.keep_rate_ph: self.keep_rate}

                _, c = self.sess.run([self.optimizer, self.model.total_cost], feed_dict)

                # Since a single epoch can take a  ages for larger models (ESIM),
                #  we'll print accuracy every 50 steps
                if self.step % self.display_step_freq == 0:
                    dev_acc, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
                    strain_acc, strain_cost = evaluate.evaluate_classifier(self.classify, train_data[0:5000],
                                                                           self.batch_size)

                    logger.Log(f"Step: {self.step}\t Dev cost: {dev_cost}\t Dev acc: {dev_acc}")

                if self.step % 500 == 0:
                    self.saver.save(self.sess, ckpt_file)
                    best_test = 100 * (1 - self.best_dev / dev_acc)
                    if best_test > 0.04:
                        self.saver.save(self.sess, ckpt_file + "_best")
                        self.best_dev = dev_acc
                        self.best_train_acc = strain_acc
                        self.best_step = self.step
                        logger.Log("Checkpointing with new best SNLI-dev accuracy: %f" % (self.best_dev))

                self.step += 1

                # Compute average loss
                avg_cost += c / (total_batch * self.batch_size)

            # Display some statistics about the epoch
            if self.epoch % self.display_epoch_freq == 0:
                logger.Log("Epoch: %i\t Avg. Cost: %f" % (self.epoch + 1, avg_cost))

            self.epoch += 1
            self.last_train_acc[(self.epoch % 5) - 1] = strain_acc

            # Early stopping
            progress = 1000 * (sum(self.last_train_acc) / (len(self.last_train_acc) * min(self.last_train_acc)) - 1)

            if (progress < 0.1) or (self.step > self.best_step + 30000):
                logger.Log("Best dev accuracy: %s" % (self.best_dev))
                logger.Log("Best train accuracy: %s" % (self.best_train_acc))
                self.completed = True
                break

    # def classify(self, examples):
    #     # This classifies a list of examples
    #     total_batch = int(len(examples) / self.batch_size)
    #     logits = np.empty(4)
    #     genres = []
    #     for i in range(total_batch):
    #         minibatch_premise_vectors, minibatch_hypothesis_vectors, minibatch_labels, minibatch_genres = self.get_minibatch(
    #             examples, self.batch_size * i, self.batch_size * (i + 1))
    #         feed_dict = {self.model.premise_x: minibatch_premise_vectors,
    #                      self.model.hypothesis_x: minibatch_hypothesis_vectors,
    #                      self.model.y: minibatch_labels,
    #                      self.model.keep_rate_ph: 1.0}
    #         genres += minibatch_genres
    #         logit, cost = self.sess.run([self.model.logits, self.model.total_cost], feed_dict)
    #         logits = np.vstack([logits, logit])
    #
    #     return genres, np.argmax(logits[1:], axis=1), cost


def train_rumor_model(classifier, logger, train_data, dev_data, test_data):
    classifier.train(train_data, dev_data)
    logger.Log(
        "Acc: %s" % (evaluate.evaluate_classifier(classifier.classify, test_data, FIXED_PARAMETERS["batch_size"]))[0])


def test_rumor_model(classifier, logger, test_data):
    results = evaluate.evaluate_final(classifier.restore, classifier.classify, [test_data],
                                      FIXED_PARAMETERS["batch_size"])
    logger.Log("Acc: %s" % (results[0][0]))


if __name__ == '__main__':
    modname = 'ensemble_rumoreval'
    test = False

    FIXED_PARAMETERS = parameters.parameters
    logger = train_shared.get_logger(FIXED_PARAMETERS, modname)
    word_indices = vocab.load_dictionary()
    logger.Log("FIXED_PARAMETERS\n %s" % FIXED_PARAMETERS)

    logger.Log("Loading embeddings")
    loaded_embeddings = data_processing.loadEmbedding_rand(FIXED_PARAMETERS["embedding_data_path"], word_indices)

    train_data, dev_data, test_data = load_rumor_data()
    rumor_processing.sentences_to_padded_index_sequences(word_indices, [train_data, dev_data, test_data])

    classifier = RumorModelTrainer(loaded_embeddings, logger, modname)
    if test:
        test_rumor_model(classifier, logger, test_data)
    else:
        train_rumor_model(classifier, logger, train_data, dev_data, test_data)

#
# class ModelClassifier:
#     def __init__(self, seq_length):
#         ## Define hyperparameters
#         self.learning_rate = rumor_processing.FIXED_PARAMETERS["learning_rate"]
#         self.display_epoch_freq = 1
#         self.display_step_freq = 50
#         self.embedding_dim = rumor_processing.FIXED_PARAMETERS["word_embedding_dim"]
#         self.dim = rumor_processing.FIXED_PARAMETERS["hidden_embedding_dim"]
#         self.batch_size = rumor_processing.FIXED_PARAMETERS["batch_size"]
#         self.emb_train = rumor_processing.FIXED_PARAMETERS["emb_train"]
#         self.keep_rate = rumor_processing.FIXED_PARAMETERS["keep_rate"]
#         self.sequence_length = rumor_processing.FIXED_PARAMETERS["seq_length"]
#         self.alpha = rumor_processing.FIXED_PARAMETERS["alpha"]
#
#         logger.Log("Building model from %s.py" % (model))
#         self.model = MyModel(seq_length=self.sequence_length, emb_dim=self.embedding_dim, hidden_dim=self.dim,
#                              embeddings=loaded_embeddings, emb_train=self.emb_train, num_labels=4)
#
#         # Perform gradient descent with Adam
#         self.optimizer = tf.train.AdamOptimizer(self.learning_rate, beta1=0.9, beta2=0.999).minimize(
#             self.model.total_cost)
#
#         # Boolean stating that training has not been completed,
#         self.completed = False
#
#         # tf things: initialize variables and create placeholder for session
#         logger.Log("Initializing variables")
#         self.init = tf.global_variables_initializer()
#         self.sess = None
#         self.saver = tf.train.Saver()
#
#     def get_minibatch(self, dataset, start_index, end_index):
#         batch = dataset[start_index:end_index]
#         premise_vectors = batch['text_index_sequence'].to_list()
#         hypothesis_vectors = batch['text_index_sequence'].to_list()
#         genres = ['none'] * len(batch)
#         labels = batch['label'].to_list()
#         return premise_vectors, hypothesis_vectors, labels, genres
#
#     def train(self, train_data, dev_data):
#         self.sess = tf.Session()
#         self.sess.run(self.init)
#
#         self.step = 1
#         self.epoch = 0
#         self.best_dev = 0.
#         self.best_train_acc = 0.
#         self.last_train_acc = [.001, .001, .001, .001, .001]
#         self.best_step = 0
#
#         # Restore most recent checkpoint if it exists.
#         # Also restore values for best dev-set accuracy and best training-set accuracy.
#         ckpt_file = os.path.join(rumor_processing.FIXED_PARAMETERS["ckpt_path"], modname) + ".ckpt"
#         if os.path.isfile(ckpt_file + ".meta"):
#             if os.path.isfile(ckpt_file + "_best.meta"):
#                 self.saver.restore(self.sess, (ckpt_file + "_best"))
#                 best_dev_mat, dev_cost_mat = evaluate.evaluate_classifier(self.classify, dev_data,
#                                                                           self.batch_size)
#                 self.best_dev, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
#                 self.best_train_acc, strain_cost = evaluate.evaluate_classifier(self.classify,
#                                                                                 train_data[
#                                                                                 0:5000],
#                                                                                 self.batch_size)
#                 logger.Log(
#                     f"""Restored best matched-dev acc: {best_dev_mat}
# Restored best acc: {self.best_dev}
# Restored best SNLI train acc: {self.best_train_acc}""")
#
#             self.saver.restore(self.sess, ckpt_file)
#             logger.Log("Model restored from file: %s" % ckpt_file)
#
#         ### Training cycle
#         logger.Log("Training...")
#
#         while True:
#             # random.shuffle(train_data) # Already should be shuffled from when they were read.
#             avg_cost = 0.
#             total_batch = int(len(train_data) / self.batch_size)
#
#             # Loop over all batches in epoch
#             for i in range(total_batch):
#                 # Assemble a minibatch of the next B examples
#                 premise_vectors, hypothesis_vectors, labels, genres = self.get_minibatch(train_data,
#                                                                                          self.batch_size * i,
#                                                                                          self.batch_size * (i + 1))
#
#                 # Run the optimizer to take a gradient step, and also fetch the value of the
#                 # cost function for logging
#                 feed_dict = {self.model.premise_x: premise_vectors,
#                              self.model.hypothesis_x: hypothesis_vectors,
#                              self.model.y: labels,
#                              self.model.keep_rate_ph: self.keep_rate}
#
#                 _, c = self.sess.run([self.optimizer, self.model.total_cost], feed_dict)
#
#                 # Since a single epoch can take a  ages for larger models (ESIM),
#                 #  we'll print accuracy every 50 steps
#                 if self.step % self.display_step_freq == 0:
#                     dev_acc, dev_cost = evaluate.evaluate_classifier(self.classify, dev_data, self.batch_size)
#                     strain_acc, strain_cost = evaluate.evaluate_classifier(self.classify, train_data[0:5000],
#                                                                            self.batch_size)
#
#                     logger.Log(f"Step: {self.step}\t Dev cost: {dev_cost}\t Dev acc: {dev_acc}")
#
#                 if self.step % 500 == 0:
#                     self.saver.save(self.sess, ckpt_file)
#                     best_test = 100 * (1 - self.best_dev / dev_acc)
#                     if best_test > 0.04:
#                         self.saver.save(self.sess, ckpt_file + "_best")
#                         self.best_dev = dev_acc
#                         self.best_train_acc = strain_acc
#                         self.best_step = self.step
#                         logger.Log("Checkpointing with new best SNLI-dev accuracy: %f" % (self.best_dev))
#
#                 self.step += 1
#
#                 # Compute average loss
#                 avg_cost += c / (total_batch * self.batch_size)
#
#             # Display some statistics about the epoch
#             if self.epoch % self.display_epoch_freq == 0:
#                 logger.Log("Epoch: %i\t Avg. Cost: %f" % (self.epoch + 1, avg_cost))
#
#             self.epoch += 1
#             self.last_train_acc[(self.epoch % 5) - 1] = strain_acc
#
#             # Early stopping
#             progress = 1000 * (sum(self.last_train_acc) / (len(self.last_train_acc) * min(self.last_train_acc)) - 1)
#
#             if (progress < 0.1) or (self.step > self.best_step + 30000):
#                 logger.Log("Best dev accuracy: %s" % (self.best_dev))
#                 logger.Log("Best train accuracy: %s" % (self.best_train_acc))
#                 self.completed = True
#                 break
#
#     def restore(self, best=True):
#         if best:
#             path = os.path.join(rumor_processing.FIXED_PARAMETERS["ckpt_path"], modname) + ".ckpt_best"
#         else:
#             path = os.path.join(rumor_processing.FIXED_PARAMETERS["ckpt_path"], modname) + ".ckpt"
#         self.sess = tf.Session()
#         self.sess.run(self.init)
#         self.saver.restore(self.sess, path)
#         logger.Log("Model restored from file: %s" % path)
#
#     def classify(self, examples):
#         # This classifies a list of examples
#         total_batch = int(len(examples) / self.batch_size)
#         logits = np.empty(4)
#         genres = []
#         for i in range(total_batch):
#             minibatch_premise_vectors, minibatch_hypothesis_vectors, minibatch_labels, minibatch_genres = self.get_minibatch(
#                 examples, self.batch_size * i, self.batch_size * (i + 1))
#             feed_dict = {self.model.premise_x: minibatch_premise_vectors,
#                          self.model.hypothesis_x: minibatch_hypothesis_vectors,
#                          self.model.y: minibatch_labels,
#                          self.model.keep_rate_ph: 1.0}
#             genres += minibatch_genres
#             logit, cost = self.sess.run([self.model.logits, self.model.total_cost], feed_dict)
#             logits = np.vstack([logits, logit])
#
#         return genres, np.argmax(logits[1:], axis=1), cost

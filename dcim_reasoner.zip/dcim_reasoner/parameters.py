"""
The hyperparameters for a model are defined here. Arguments like the type of model, model name, paths to data, logs etc. are also defined here.
All paramters and arguments can be changed by calling flags in the command line.

Required arguements are,
model_type: which model you wish to train with. Valid model types: cbow, bilstm, and esim.
model_name: the name assigned to the model being trained, this will prefix the name of the logs and checkpoint files.
"""

import argparse
import io
import os
import json

data_path = '../data'

parameters = {
    'model_type': 'esim',
    'learning_rate': 0.0004,
    'keep_rate': 0.5,
    'seq_length': 50,
    'batch_size': 32,
    'word_embedding_dim': 50,
    'hidden_embedding_dim': 50,
    'embedding_data_path': f'{data_path}/glove.6B.50d.txt',
    'log_path': '../logs',
    'ckpt_path': '../logs'
}

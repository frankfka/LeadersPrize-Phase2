import csv

import pandas as pd
import numpy as np
import predict_ensemble
import predict_shared


def get_sentences(text):
    sentences = text.replace('?', '.').replace('!', '.').split('.')
    sentences = [sentence for sentence in sentences if len(sentence) >= 5]
    return sentences


def safe_get_column(source, name):
    try:
        column = source[name]
    except KeyError:
        column = pd.Series(0, index=source.index)
    return column


def paraphrase_score_to_label(score):
    if score > 0:
        return 'paraphrase'
    else:
        return 'not_paraphrase'


def entailment_score_to_label(score):
    if score > 0.33:
        return 'entailment'
    elif score > -0.033:
        return 'not_entailment'
    else:
        return 'contradiction'


def rumor_scores_to_label(comment, support, deny, query):
    max_score = max(comment, support, deny, query)
    if max_score == comment:
        return 'Comment'
    elif max_score == support:
        return 'Support'
    elif max_score == deny:
        return 'Deny'
    elif max_score == query:
        return 'Query'
    else:
        assert False


if __name__ == '__main__':
    classifier = predict_ensemble.EnsembleClassifier()

    hypotheses = predict_shared.hypotheses
    article_names, articles = predict_shared.load_articles(path='datainput_small')

    output_path = '../output'
    for hypothesis_i, hypothesis in enumerate(hypotheses):
        hypothesis_df = pd.DataFrame()
        for article_name, article in zip(article_names, articles):
            sentences = get_sentences(article)
            predictions = classifier.predict_statement_in_contexts(statement=hypothesis, contexts=sentences)
            article_df = pd.DataFrame(predictions)
            article_df['article'] = article_name
            article_df['line'] = range(len(article_df))
            article_df['hypothesis'] = hypothesis
            article_df['sentence'] = sentences
            hypothesis_df = hypothesis_df.append(article_df)

        path = f'{output_path}/{hypothesis_i}_sentence_predictions.csv'

        hypothesis_df.to_csv(path)

        entailment_counts = hypothesis_df.groupby('article')['entailment'].value_counts().unstack().fillna(0)
        entailment_counts = entailment_counts.rename(columns={'neutral': 'no_entailment'})

        paraphrase_counts = hypothesis_df.groupby('article')['paraphrase'].value_counts().unstack().fillna(0)
        paraphrase_counts = paraphrase_counts.rename(columns={'neutral': 'no_paraphrase'})

        rumor_counts = hypothesis_df.groupby('article')['rumor'].value_counts().unstack().fillna(0)

        classification_density_df = (entailment_counts
                                     .join(paraphrase_counts)
                                     .join(rumor_counts))

        # Could fail if nothing is classified as paraphrase
        classification_density_df = classification_density_df.div(
            hypothesis_df.groupby('article').count()['paraphrase'], axis=0)

        entailment_density = safe_get_column(classification_density_df, 'entailment')
        contradiction_density = safe_get_column(classification_density_df, 'contradiction')
        entailment_score = entailment_density - contradiction_density

        paraphrase_density = safe_get_column(classification_density_df, 'paraphrase')
        no_paraphrase_density = safe_get_column(classification_density_df, 'no_paraphrase')
        paraphrase_score = paraphrase_density - no_paraphrase_density

        comment = safe_get_column(classification_density_df, 'comment')
        support = safe_get_column(classification_density_df, 'support')
        deny = safe_get_column(classification_density_df, 'deny')
        query = safe_get_column(classification_density_df, 'query')
        rumor_label = np.vectorize(rumor_scores_to_label)(comment, support, deny, query)

        summary_df = pd.DataFrame({
            'hypothesis': hypothesis,
            'article': entailment_score.index,
            'entailment_label': entailment_score.map(entailment_score_to_label),
            'entailment_score': entailment_score,
            'paraphrase_label': paraphrase_score.map(paraphrase_score_to_label),
            'paraphrase_score': paraphrase_score,
            'rumor_label': rumor_label
        })
        summary_df = summary_df.join(classification_density_df)

        summary_path = f'{output_path}/{hypothesis_i}_summary.csv'
        summary_df.to_csv(summary_path)

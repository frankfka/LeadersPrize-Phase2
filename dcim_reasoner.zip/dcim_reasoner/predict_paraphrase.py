"""
Script to generate a CSV file of predictions on the test data.
"""

import importlib
import os

import data_processing
import parameters
import predict_shared
import vocab
import logger_mod
import paraphrase_util.data_processing
from paraphrase_util.evaluate import *
import pickle
import tensorflow.compat.v1 as tf
import bs4
import tokenize as tokenizelib
import numpy as np
import csv

tf.disable_v2_behavior()


def predict_for_hypothesis_and_article(hypothesis, article, name):
    sentences = article.split('.')
    sentences = [sentence for sentence in sentences
                 if len(sentence) >= 5]
    pairs = [
        {
            'sentence0': article_sentence,
            'sentence1': hypothesis,
            'pairID': f'{name}_{i}'
        } for i, article_sentence in enumerate(sentences)
    ]
    pair_df = pd.DataFrame(pairs)
    paraphrase_util.data_processing.sentences_to_padded_index_sequences(word_indices, [pair_df])
    predictions = get_predictions(classifier.classify, pair_df)

    label_to_score = {
        'paraphrase': 1,
        'neutral': 0,
    }

    rows = []
    for pair, prediction in zip(pairs, predictions):
        row = (pair['sentence1'], pair['sentence0'], pair['pairID'], prediction[1])
        rows.append(row)

    total_score = 0
    for prediction in predictions:
        label = prediction[1]
        score = label_to_score[label]
        total_score += score
    total_score /= len(predictions)
    return rows, total_score


def predict_for_hypothesis(hypothesis, articles, article_names):
    all_predictions = []
    scores = []
    for article, name in zip(articles, article_names):
        hypothesis_predictions, score = predict_for_hypothesis_and_article(hypothesis, article, name)
        all_predictions += hypothesis_predictions
        row = (name, score)
        scores.append(row)
    return all_predictions, scores


def save_hypothesis_predictions(hypothesis_predictions):
    with open('../data/my/sentence_predictions.csv', 'w+', errors='ignore') as f:
        writer = csv.writer(f)
        writer.writerows(hypothesis_predictions)
    name = f'{modname}_hypothesis_{hypothesis_i}'
    save_predictions(hypothesis_predictions, name)


if __name__ == '__main__':
    modname = 'ensemble_paraphrase'
    test = False

    FIXED_PARAMETERS = parameters.parameters

    logpath = os.path.join(FIXED_PARAMETERS["log_path"], modname) + ".log"
    logger = logger_mod.Logger()
    logger.Log("FIXED_PARAMETERS\n %s" % FIXED_PARAMETERS)
    logger.Log("Loading data")
    word_indices = vocab.load_dictionary()

    data_root_path = '../data'
    embedding_path = f'{data_root_path}/glove.6B.50d.txt'
    loaded_embeddings = data_processing.loadEmbedding_rand(embedding_path, word_indices)

    classifier = predict_shared.modelClassifier(loaded_embeddings=loaded_embeddings,
                                                processing=paraphrase_util.data_processing,
                                                logger=logger,
                                                modname=modname)
    # #
    classifier.restore()
    article_names, articles = predict_shared.load_articles()

    csv_rows = []
    for hypothesis_i, hypothesis in enumerate(predict_shared.hypotheses):
        hypothesis_predictions, scores = predict_for_hypothesis(hypothesis, articles, article_names)
        save_hypothesis_predictions(hypothesis_predictions)
        for article, score in scores:
            row = [hypothesis, article, score]
            csv_rows.append(row)

    with open(f'{modname}_main_output.csv', 'w+') as f:
        writer = csv.writer(f)
        writer.writerows(csv_rows)

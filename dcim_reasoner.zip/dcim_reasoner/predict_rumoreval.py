"""
Script to generate a CSV file of predictions on the test data.
"""

import os

import parameters
import predict_shared
import logger_mod
import data_processing
import rumoreval_util.data_processing as processing
from rumoreval_util.evaluate import *
import pickle
import tensorflow.compat.v1 as tf
import csv
import numpy as np
import models.esim

tf.disable_v2_behavior()


def predict_for_article(article, name):
    sentences = article.split('.')
    sentences = [sentence for sentence in sentences
                 if len(sentence) >= 5]
    pairs = [
        {
            'text': article_sentence,
            'pairID': f'{name}_{i}'
        } for i, article_sentence in enumerate(sentences)
    ]
    pair_df = pd.DataFrame(pairs)
    processing.sentences_to_padded_index_sequences(word_indices, [pair_df])
    predictions = get_predictions(classifier.classify, pair_df)

    rows = []
    for pair, prediction in zip(pairs, predictions):
        row = (pair['text'], pair['pairID'], prediction[1])
        rows.append(row)

    return rows


def predict(articles, article_names):
    all_predictions = []
    for article, name in zip(articles, article_names):
        predictions = predict_for_article(article, name)
        all_predictions += predictions
        # break  # todo remove
    return all_predictions


def save_predictions(predictions):
    name = f'{modname}'
    with open(name + '_predictions.csv', 'w', errors='ignore') as f:
        w = csv.writer(f, delimiter=',')
        w.writerow(['Text', 'Label'])
        for example in predictions:
            w.writerow(example)


class RumorEvalClassifier(predict_shared.modelClassifier):

    def __init__(self, loaded_embeddings, processing, logger, modname):
        tf.reset_default_graph()
        self.processing = processing
        self.logger = logger
        self.modname = modname

        ## Define hyperparameters
        self.learning_rate = self.processing.FIXED_PARAMETERS["learning_rate"]
        self.display_epoch_freq = 1
        self.display_step_freq = 50
        self.embedding_dim = self.processing.FIXED_PARAMETERS["word_embedding_dim"]
        self.dim = self.processing.FIXED_PARAMETERS["hidden_embedding_dim"]
        self.batch_size = self.processing.FIXED_PARAMETERS["batch_size"]
        self.keep_rate = self.processing.FIXED_PARAMETERS["keep_rate"]
        self.sequence_length = self.processing.FIXED_PARAMETERS["seq_length"]

        self.model = models.esim.EsimModel(seq_length=self.sequence_length, emb_dim=self.embedding_dim,
                                           hidden_dim=self.dim,
                                           embeddings=loaded_embeddings, emb_train=False,
                                           num_labels=4
                                           )

        # Perform gradient descent with Adam
        self.optimizer = tf.train.AdamOptimizer(self.learning_rate, beta1=0.9, beta2=0.999).minimize(
            self.model.total_cost)

        # tf things: initialize variables and create placeholder for session
        self.logger.Log("Initializing variables")
        self.init = tf.global_variables_initializer()
        self.sess = None
        self.saver = tf.train.Saver()

    def get_minibatch(self, dataset, start_index, end_index):
        batch = dataset[start_index: end_index]
        vectors = np.vstack(batch['text_index_sequence'])
        return vectors

    def classify(self, examples):
        # This classifies a list of examples
        best_path = os.path.join(self.processing.FIXED_PARAMETERS["ckpt_path"], self.modname) + ".ckpt_best"
        self.sess = tf.Session()
        self.sess.run(self.init)
        self.saver.restore(self.sess, best_path)
        self.logger.Log("Model restored from file: %s" % best_path)

        logits = np.empty(4)
        minibatch_vectors = self.get_minibatch(examples, 0, len(examples))
        feed_dict = {self.model.premise_x: minibatch_vectors,
                     self.model.hypothesis_x: minibatch_vectors,
                     self.model.keep_rate_ph: 1.0}
        logit = self.sess.run(self.model.logits, feed_dict)
        logits = np.vstack([logits, logit])

        return np.argmax(logits[1:], axis=1)


if __name__ == '__main__':
    FIXED_PARAMETERS = parameters.parameters
    modname = FIXED_PARAMETERS["model_name"]
    logpath = os.path.join(FIXED_PARAMETERS["log_path"], modname) + ".log"
    logger = logger_mod.Logger(logpath)
    logger.Log("FIXED_PARAMETERS\n %s" % FIXED_PARAMETERS)
    logger.Log("Loading data")
    dictpath = os.path.join(FIXED_PARAMETERS["log_path"], modname) + ".p"
    if not os.path.isfile(dictpath):
        print("No dictionary found!")
        raise FileNotFoundError
    word_indices = pickle.load(open(dictpath, "rb"))
    loaded_embeddings = data_processing.loadEmbedding_rand(FIXED_PARAMETERS["embedding_data_path"], word_indices)
    # classifier = predict_shared.modelClassifier(loaded_embeddings, processing, logger)
    classifier = RumorEvalClassifier(loaded_embeddings, processing, logger, modname)
    # #

    article_names, articles = predict_shared.load_articles()

    csv_rows = []
    # for hypothesis_i, hypothesis in enumerate(predict_shared.hypotheses):
    predictions = predict(articles, article_names)
    save_predictions(predictions)

    # with open(f'{modname}_main_output.csv', 'w+') as f:
    #     writer = csv.writer(f)
    #     writer.writerows(csv_rows)
